 var popupDiv = document.getElementById("popup-vindu");

function openPopUpMenu(){
    popupDiv.style.display = "block";
}

function closePopUpMenu(){
    popupDiv.style.display = "none";
}
 