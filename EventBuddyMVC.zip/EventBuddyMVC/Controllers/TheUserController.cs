using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using EventBuddyMVC.Models;
using System.IO;
using System.Dynamic;

namespace EventBuddyMVC.Controllers
{

    public class TheUserController : Controller
    {

        private readonly UserContext _context;
        private readonly IHostingEnvironment _hostingEnviroment;

        public TheUserController(UserContext context, IHostingEnvironment hostingEnviroment)
        {
            _context = context;
            _hostingEnviroment = hostingEnviroment;

        }
        public IActionResult AllUsers()
        {

            return View();
        }

        [HttpGet]
        public ActionResult FrontPage()
        {
            if(HttpContext.Session.GetString("UserName")!=null){
               ViewData["Session_Name"] = HttpContext.Session.GetString("UserName");
               
           }
            return View();
        }

        [HttpPost]
        public async Task <IActionResult> FrontPage([Bind("UserName, Password")]User user)
        {
            if(ModelState.IsValid){
                HttpContext.Session.SetString("UserName", user.UserName);
                ViewData["Session_Name"] = HttpContext.Session.GetString("Username");
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(LoggedIn));
            }else{
                return View();
            }
        }

        public IActionResult LoggedIn()
        {
            if(HttpContext.Session.GetString("UserName")!=null){
               ViewData["Session_Name"] = HttpContext.Session.GetString("UserName");
               
           }
            return View();
        }

        public async Task<IActionResult> Events()
        {
            List<Events> eventsList = await _context.Events.ToListAsync();
            return View(eventsList);
        }
         public async Task<IActionResult> EditEvent(int? id){
            Events events = await _context.Events.SingleOrDefaultAsync(_events => _events.ID == id);
            return View(events);
        }
         [HttpPost]
        public async Task<IActionResult> EditEvent(int? id, [Bind("ID, Category, GroupName, ImageSrc")] Events events, List<IFormFile> file){
             string webRootPath =  _hostingEnviroment.WebRootPath;
                var uploadAbsolutePath = Path.Combine(webRootPath + "/images", file[0].FileName);
                using (var fileStream = new FileStream(uploadAbsolutePath, FileMode.Create))
                {
                    file[0].CopyTo(fileStream);
                    events.ImageSrc = file[0].FileName;
                }
            _context.Update(events);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Events));
        }

         public async Task<IActionResult> DeleteEvent(int? id)
        {
            Events events = await _context.Events.SingleOrDefaultAsync(_events => _events.ID == id);
            return View(events);
        }

          [HttpPost, ActionName("DeleteEvent")]
        public async Task<IActionResult> DeleteEventConfirm(int? id)
        {
            Events events = await _context.Events.SingleOrDefaultAsync(_events => _events.ID == id);
            _context.Events.Remove(events);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(myEvents));
        }

           public IActionResult CreateEvent()
        {
            return View();
        }

         [HttpPost]
        public async Task<IActionResult> CreateEvent([Bind("ID, Category, GroupName, ImageSrc")] Events events, List<IFormFile> file)
        {
           
                string webRootPath =  _hostingEnviroment.WebRootPath;
                var uploadAbsolutePath = Path.Combine(webRootPath + "/images", file[0].FileName);
                using (var fileStream = new FileStream(uploadAbsolutePath, FileMode.Create))
                {
                    file[0].CopyTo(fileStream);
                    events.ImageSrc = file[0].FileName;
                }
                _context.Add(events);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Events));
            

        }
         public async Task<IActionResult> myEvents()
        {
            List<Events> eventsList = await _context.Events.ToListAsync();
            return View(eventsList);
        }


         public IActionResult Forum()
        {
            return View();
        }
         public IActionResult MakeEvents()
        {
            return View();
        }
         public IActionResult Matches()
        {
            return View();
        }


        public IActionResult NewProfile()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> NewProfile([Bind("ID, Name, Age, School, Hobbies, Bio, ImageSrc")] Profile profile, List<IFormFile> file)
        {
              string webRootPath = _hostingEnviroment.WebRootPath;
                var uploadAbsolutePath = Path.Combine(webRootPath + "/images", file[0].FileName);
                using (var fileStream = new FileStream(uploadAbsolutePath, FileMode.Create))
                {
                    file[0].CopyTo(fileStream);
                    profile.ImageSrc = file[0].FileName;
                }
                _context.Add(profile);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(LoggedIn));
        }

        [HttpGet]
         public async Task<IActionResult> Profile()
        {
            List<Profile> profileList = await _context.Profile.ToListAsync();
            return View(profileList);
        }
         public async Task<IActionResult> EditProfile(int? id)
        {
            Profile profile = await _context.Profile.SingleOrDefaultAsync(_profile => _profile.ID == id);
            return View(profile);
        }
        [HttpPost]
        public async Task<IActionResult> EditProfile(int? id, [Bind("ID, Name, Age, School, Hobbies, Bio, ImageSrc")] Profile profile, List<IFormFile> file)
        {
            string webRootPath =  _hostingEnviroment.WebRootPath;
                var uploadAbsolutePath = Path.Combine(webRootPath + "/images", file[0].FileName);
                using (var fileStream = new FileStream(uploadAbsolutePath, FileMode.Create))
                {
                    file[0].CopyTo(fileStream);
                    profile.ImageSrc = file[0].FileName;
                }
            
            _context.Update(profile);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Profile));
        }

         [HttpGet]
        public ActionResult NewUser()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> NewUser([Bind("UserName, Password")] User newUser)
        {
            if (ModelState.IsValid)
            {
                 HttpContext.Session.SetString("UserName", newUser.UserName);
                ViewData["Session_Name"] = HttpContext.Session.GetString("Username");
                await _context.SaveChangesAsync();
               
                return RedirectToAction(nameof(NewProfile));
            }
            else
            {
                return View();
            }
        }
         public IActionResult AboutUs()
        {
            return View();
        }
         public IActionResult ContactUs()
        {
            return View();
        }
         public IActionResult ForgotPassword()
        {
            return View();
        }









    }


}