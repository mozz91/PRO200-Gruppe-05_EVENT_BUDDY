





function join(){
   
    
    alert("You have joined this event");
    
}
