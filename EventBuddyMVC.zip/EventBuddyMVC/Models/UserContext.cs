using Microsoft.EntityFrameworkCore;

namespace EventBuddyMVC.Models{

    public class UserContext:DbContext{
        public UserContext(DbContextOptions<UserContext> options):base(options){}

        public DbSet<User> User { get; set; }
        public DbSet<Events> Events { get; set; }

        public DbSet<Profile> Profile {get; set;}







    }
}