using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventBuddyMVC.Models{

    public class Profile{

        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Required")]
        public int Age { get; set; }
        [Required(ErrorMessage = "Required")]
        public string School { get; set; }

        public string Hobbies { get; set; }
        public string Bio { get; set; }
        public string ImageSrc { get; set; }

        public static implicit operator Profile(List<Profile> v)
        {
            throw new NotImplementedException();
        }
    }
}