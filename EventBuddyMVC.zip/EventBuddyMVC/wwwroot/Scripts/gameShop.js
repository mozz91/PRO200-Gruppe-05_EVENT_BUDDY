let personApp = new Vue({
    el: '[data-init="component-one"]',
    data: {
        personList: [{
                Name: "Name: Lene",
                Age: "Age: 22",
                Interests: "Interests: Acting, Singer",
                imageSrc: "/images/9.jpg",
                
            },
            {
                Name: "Name: Thomas",
                Age: "Age: 21",
                Interests: "Interests: Fotball, Movies",
                imageSrc: "/images/3.jpg",
            },
            {
                Name: "Name: Eric",
                Age: "Age: 27",
                Interests: "Interests: Farming, Tractor, Animals",
                imageSrc: "/images/7.jpg"
            },
            {
                Name: "Name: Rozie",
                Age: "Age: 20",
                Interests: "Interests: Gaming, Tv-Shows",
                imageSrc: "/images/2.jpg",
            },
            {
                Name: "Name: Martin",
                Age: "Age: 35",
                Interests: "Interests: Airsoft, Golf",
                imageSrc: "/images/4.jpg",
            },
            {
                Name: "Name: Abaz",
                Age:"Age: 19",
                Interests: "Interests: Wrestling, Boxing, UFC",
                imageSrc: "/images/5.jpg",
            }
        ],
        currentBgPath: "",
    },
    
    methods: {
        
        created(){
            for(let i = 0; i < this.personList.length; i++){
            var random = Math.floor(Math.random() * this.personList.length);
            this.currentBgPath = this.personList[random];
        }
        },

        join(){
            alert("hei");
        }
    }
});
