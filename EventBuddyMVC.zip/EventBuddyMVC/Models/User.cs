using System.ComponentModel.DataAnnotations;

namespace EventBuddyMVC.Models{

    public class User{

        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "Required")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Required")]
        public string Password { get; set; }
    }
}