using System.ComponentModel.DataAnnotations;

namespace EventBuddyMVC.Models{

    public class Events{
        [Key]

        public int ID { get; set; }

        public string Category { get; set; }
        public string GroupName { get; set; }
        public string ImageSrc { get; set; }
    }
}